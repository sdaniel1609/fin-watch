const firebaseConfig = {
  apiKey: "AIzaSyCjXDygaQ2jsmjdCtuZKnd1ZH9ZXEJMWCA",
  authDomain: "menu-scanner-35f14.firebaseapp.com",
  projectId: "menu-scanner-35f14",
  storageBucket: "menu-scanner-35f14.appspot.com",
  messagingSenderId: "72609415985",
  appId: "1:72609415985:web:f2c52b937780c09a41e610",
  measurementId: "G-EL68TMB7X7"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

//url for menu when scanning QR code
const menuUrl = 'https://firebasestorage.googleapis.com/v0/b/menu-scanner-35f14.appspot.com/o/abi-cafe-menu.pdf?alt=media&token=c21879a4-f6c1-4eea-a99e-1f01916954eb'

//generates QR code 
const qr =  new QRious({
  element: document.getElementById('qr-code'),
  size: 200,
  value: menuUrl
});

// menu to upload 
let files = [];
document.getElementById("file").addEventListener("change", function(e) {
  files = e.target.files;
});

// function called when generating QR Code
function generateQR() {
  qr.set({
      foreground: 'black',
      size: 200,
  });
}

//function called when clicking update menu
function updateMenu() {
   //checks if menu is selected
   //only process 1 menu
   if (files.length === 1) {

    //Loops through all the selected menu
    for (let i = 0; i < files.length; i++) {
  
      //create a storage reference
      var storage = firebase.storage().ref("abi-cafe-menu.pdf");
  
      //upload menu to firebase storage
      storage.put(files[i]);
    }
    } else {
      alert('Select menu to update')
    }
}

